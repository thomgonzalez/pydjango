from django.contrib import admin

# Register your models here.
from test_web.apps.principal.models import Cia, Domicilio

admin.site.register(Cia)
admin.site.register(Domicilio)
