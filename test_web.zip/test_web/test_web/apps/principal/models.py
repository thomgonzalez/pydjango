from django.db import models

# Create your models here.
class Cia(models.Model):
	nombre = models.CharField(max_length=100)
	rfc = models.CharField(max_length=13)


class Domicilio(models.Model):
	codigo_postal = models.CharField(max_length=5)
	calle = models.CharField(max_length=100)
	no_int = models.CharField(max_length=10)
	no_ext = models.CharField(max_length=10)
	