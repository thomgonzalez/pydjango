from django.conf.urls import patterns, url
from test_web.apps.principal.views import home

urlpatterns = [
    url(r'^$', home, name='home_url'),
]
