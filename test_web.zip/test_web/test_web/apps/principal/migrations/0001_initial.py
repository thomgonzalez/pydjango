# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Cia',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('nombre', models.CharField(max_length=100)),
                ('rfc', models.CharField(max_length=13)),
            ],
        ),
        migrations.CreateModel(
            name='Domicilio',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('codigo_postal', models.CharField(max_length=5)),
                ('calle', models.CharField(max_length=100)),
                ('no_int', models.CharField(max_length=10)),
                ('no_ext', models.CharField(max_length=10)),
            ],
        ),
    ]
